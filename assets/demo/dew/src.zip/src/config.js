const path = require('path')

module.exports = {
  distDir: path.resolve(__dirname, './build'),
  targetDir: path.resolve(__dirname, '../../src/main/webapp/react'),
}
