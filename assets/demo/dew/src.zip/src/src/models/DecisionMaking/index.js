import config from './config'
import finance from './finance'
import focus from './focus'
import nodeList from './nodeList'

export default [
  config,
  finance,
  focus,
  nodeList,
]
