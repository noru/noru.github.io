
module.exports = {

  red: '#D050A3',
  blue: '#6A98E7',
  gray: '#ABABAC',
  purple: '#B276AF',
  yellow: '#D0BA54',
  green: '#5CAC9C',
  text: '#919191',

}