export const assetsInMaintain = [
  {
    "assetInfoId": 0,
    "assetInfoUID": "string",
    "financingNum": "string",
    "reportDate": "2018-08-09T04:41:04.872Z",
    "status": "string",
    "reporter": "Trump",
    "assetName": "asset name",
    "clinicalDept": "Dept",
  },
  {
    "assetInfoId": 0,
    "assetInfoUID": "string",
    "financingNum": "string",
    "reportDate": "2017-08-09T04:41:04.872Z",
    "status": "string",
    "reporter": "Trump",
    "assetName": "asset name",
    "clinicalDept": "Dept",
  },

]

export const avgResponseTime = [
  {
    "assetGroup": 0,
    "assetGroupName": "string",
    "avgResponseTime": 100
  },
  {
    "assetGroup": 0,
    "assetGroupName": "string1",
    "avgResponseTime": 97
  },
  // {
  //   "assetGroup": 0,
  //   "assetGroupName": "string",
  //   "avgResponseTime": 100
  // },
  // {
  //   "assetGroup": 0,
  //   "assetGroupName": "string1",
  //   "avgResponseTime": 97
  // },
  // {
  //   "assetGroup": 0,
  //   "assetGroupName": "string",
  //   "avgResponseTime": 100
  // },
  // {
  //   "assetGroup": 0,
  //   "assetGroupName": "string1",
  //   "avgResponseTime": 97
  // },
  // {
  //   "assetGroup": 0,
  //   "assetGroupName": "string",
  //   "avgResponseTime": 100
  // },
]
