export const phaseETTR = {
  "data": {
    "phase1": 31,
    "phase2": 116,
    "phase3": 119,
    "phase4": 226
  }
}

export const phaseArrival = {
  "data": {
    "phase1": 110,
    "phase2": 164,
    "phase3": 199,
    "phase4": 260
  }
}

export const phaseRespond = {
  "data": {
    "phase1": 102,
    "phase2": 164,
    "phase3": 195,
    "phase4": 350
  }
}
