export const grossByDept = {
  "data": {
    "respond": 4977,
    "arrived": 7164,
    "ack": 10000,
    "ETTR": 11757,
    "dispatchTime": 2963,
    "workingTime": 9375,
    "ETTR75": 7299,
    "ETTR95": 88694
  }
}

export const grossByType = {
  "data": {
    "respond": 4977,
    "arrived": 7164,
    "ack": 10000,
    "ETTR": 11757,
    "dispatchTime": 2963,
    "workingTime": 9375,
    "ETTR75": 7299,
    "ETTR95": 88694
  }
}

export const grossBySupplier = {
  "data": {
    "respond": 4977,
    "arrived": 7164,
    "ack": 10000,
    "ETTR": 11757,
    "dispatchTime": 2963,
    "workingTime": 9375,
    "ETTR75": 7299,
    "ETTR95": 88694
  }
}
