/* @flow */
import React from 'react'

import DataProvider from './dataProvider'
import Chart from './chart'

export default DataProvider(Chart)
