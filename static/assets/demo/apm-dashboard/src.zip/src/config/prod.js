module.exports = {
  publicPath: '/dashboard/',
  basename: '',
  apiPrefix: '/gateway',
  urlPrefix: '/geapm',
}