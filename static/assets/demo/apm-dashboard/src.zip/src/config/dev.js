module.exports = {
  publicPath: '/',
  basename: '',
  apiPrefix: '/gateway',
  urlPrefix: 'http://localhost:8080/geapm',
}