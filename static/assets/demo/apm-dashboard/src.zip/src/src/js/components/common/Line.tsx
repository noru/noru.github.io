import Echart from './EChartBase'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legendScroll'

export default class Line extends Echart {

}