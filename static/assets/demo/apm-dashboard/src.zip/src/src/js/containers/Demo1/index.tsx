// import React from 'react'
import Dashboard2 from 'containers/dashboard2/Dashboard'
import FakeTabWrapper from '../Demo2/FakeTabWrapper'
import './index.scss'

export default FakeTabWrapper('1', 'dashboard1')(Dashboard2)