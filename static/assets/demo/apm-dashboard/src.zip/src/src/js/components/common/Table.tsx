import * as React from 'react'
import ReactTable from 'react-table'
import 'react-table/react-table.css'

export default function Table(props) {

  return <ReactTable {...props} />

}
