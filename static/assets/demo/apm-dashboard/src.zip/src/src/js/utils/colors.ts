export default {
  blue: '#346B8A',
  green: '#1F997F',
  red: '#7D3C82',
  yellow: '#9A893A',
  purple: '#8E8FC5',
  turquoise: '#68BBCB',
}