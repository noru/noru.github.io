import Echart from './EChartBase'
import 'echarts/lib/chart/pie'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/legendScroll'

export default class Pie extends Echart {

}