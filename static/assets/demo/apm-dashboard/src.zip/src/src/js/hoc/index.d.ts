
declare type HOC = (input: React.ComponentClass) => React.ComponentClass
