import * as React from 'react'
// import classname from 'classname'

export default class NotFound extends React.PureComponent<any, any> {

  render() {

    return (
      <div className="not-found-page" >
        <span>404 Not Found</span>
      </div>
    )
  }

}
