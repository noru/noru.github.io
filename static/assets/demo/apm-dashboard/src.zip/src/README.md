# Dew Dashboard

#### Run local
```
npm run dev
```

#### Run built file locally
```
npm run prod
```

#### Build
```
npm run build
```

#### Deploy

Setup key files and then run, open `push.sh` to see details
```
bash push.sh {env}
```