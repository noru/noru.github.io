import { load } from '#/js/services/mocks/helper'

export default function() {
  load('./device.ts')
  load('./user.ts')
}
