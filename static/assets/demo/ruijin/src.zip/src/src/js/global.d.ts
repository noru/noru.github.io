
declare module '*.png' {
    const value: any
    export = value
}

declare module '*.jpg' {
  const value: any
  export = value
}

declare module module {
  let hot: any
}

declare var __USE_MOCK__: boolean

interface NodeRequire {
  ensure: any
}