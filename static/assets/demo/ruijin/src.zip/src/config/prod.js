module.exports = {
  publicPath: '/cpmboard/ruijin/build/',
  basename: '',
}