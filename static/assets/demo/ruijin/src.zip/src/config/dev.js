module.exports = {
  publicPath: '/',
  basename: '',
}